## Version 2.0.2

### Changes:
- fixed minor bugs
- new component streamer (prototype)

## Version 2.0.1

### Changes:
- change buttons.less > button:active for remove dead zone tearly text in button
- added new method value to slider

### Limitation:
- no responsive module (only prototype)
- no tiles drag feature